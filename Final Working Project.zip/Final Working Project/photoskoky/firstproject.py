print("i love amideast") 
print ("i love the stem center")
print("i love amideast"); print ("i love the stem center")
if True:
    print("i live amideast")           
    #this is comment
    # who created the file
    # why the file is created
    #when the file is created 
   #-------------------
   #this 
   #is 
   #multiple line comment
   #-------------------
print(type(10))
print(type(100))
print(type(1000))
print(type(10.9))
print(type(-10.88))
print(type("hello python"))
print(type([1, 2, 3, 4, 5, 6]))
print(type((1, 2, 3, 4, 5, 6)))
print(type({"one":1, "two": 2}))
print (2==2)
print (2==4)
print (type(2==2))
myVariable = "Ammar Nasser"
print(myVariable)
print(type(myVariable))
myVariable1=66
print(myVariable1)
print(type(myVariable1))
Age= 55
print(Age)
#Source Code :The original code that we write
#Translation :Converting source code into the machine language
#Compilation: Translate and check the code before the run timeX
#python change data quicly and not get error
# you have to know that are the reserved words to not use it as a variable
#python is very good in the error handeling
X = 10
X = ("HELLO")
print(X)
help('keywords')
a, b, c = 1, 2, 3
print(a)
print(b)
print(c)
d, e, f = 4, 5, 6
print(d)
print(e)
print(f)
print("MY NAME IS AMMAR")
# more about the charachters
#\b   back space
print("hello\bworld")
#\ Escape the new lines
print("hello \
world")
# in case you want to print the back slash
print("i love the back slash\\single quote")
# in case you want to ESCAPE SINGLE QUOTE \
print('i love the back slash  \'TEST\'')
#Line feed (for new line) \n
print("i love my dad\ni love my mom")
# replace charcter with other charcters \r
print("1234567\rabcde")
# horizontal tab \t to make tab in the code
print("i love python\tamideast")
# the character hex value  \xthen the letters
# each one write his name with this way
print("\x61\x6d\x6d\x61\x72")
# concatenation   ( connecting strings togethere)
msg1= ("i love ")
msg2= ("egypt")
print(msg1 + msg2)
full= msg1 + msg2
print(full)
h="first \
second \
third"
g="a \
b \
c"
print (h+ "\n"+g)
myString1= "this is the first string"
myString2= 'this is the second string "test"'
print(myString2)
myString5= """i want to write many lines
this is my code
i practice python inside amideast"""
print(myString5)
# indexing ( how to access single element)
myString6=("i love python")
print(myString6[0])
print(myString6[10])
print(myString6[-1])
# slicing ( taking multiple elements in the lines) [start:end]
print(myString6[0:6])
# if start is not here will not start from zero
print(myString6[:6])
# if end is not here will go to the end
print(myString6[0:])
# for the steps = 1 so will not miss any letter
print(myString6[0::1])
# for the steps = 2 so will  miss 1 letter
print(myString6[0::2])
# len is used for the lenght of the variable
w= ("we love the usembassy")
print(len(w))
#strip is for deleting spaces and unused characters
r= ("   i love programming   ")
print(r.strip())
t= ("####i love programming####")
print(t.strip("#"))
# title is used for making the letters capital.
p= ("i love 3d designing and 4g technology")
print(p.title())
# z fill is for putting the zeros befor the numbers to complete the pattern correcrtly
1
2
3
4
5
6
10
66
55
105
109
120
200

m, n, v = "1",  "22", "444"
print(m)
print(n)
print(v)

print(m.zfill(3))
print(n.zfill(3))
print(v.zfill(3))
# upper and lower is using for the capital and small values.
name2= "ahmed"
name3= "AHMED"
print(name2.upper())
print(name3.lower())
# now lets go with the formatting
# to  print integar with string
myname= "ammarnasser"
Age= 24
rank= 10.5
# print("my name is: " + myname + "and my age is: " + Age)    ( this will get an error)
print("my name is: %s and my age is: %d" %(myname, Age))
print("my name is: %s and my age is: %d and my rank is: %f" %(myname, Age, rank))
# %s for string     %d for integer     %f for float  and this is called placeholder

k= "khaled"
l= "programmer"
f= 7
print("my name is %s iam %s i have %d years exp in pragramming"% (k, l, f))
# the replace method is used for replacing the words or numbers
o= "Hello one one one two two three"
print(o. replace("one", "1"))
# the join method (using with iterable)
mylist1= ["ammar", "nassern", "abd-elkader"]
print(type(mylist1))
print("/". join(mylist1))
print(" ". join(mylist1))
print(",". join(mylist1))
print(type("/". join(mylist1)))

#complex number
mycomplex= 5+6j
print(type(mycomplex))

#you can convert from float to any type
#you can convert from integer to any type
#you cannot convert complex to ant type
print(100)
print(float(100))
print(complex(100))

print(100.5)
print(int(100))
print(complex(100))
print(100 + 30)
print(-100+50)
print(10.2 + 20.8)
print(60-30)
print(5.5-0.5)
print(10*3)
print(10+100*5)
print((10+100)*5)
print(100/2)
print(int(100/2))
print(8%2)  # this is modulus
print(9%2)     #how we can subtract fron the 9 to give perfect number
print(22%5)
print(2**5)    # this is exponent
print(2*2*2*2*2)
print(100//20)    #this is floor division
print(119//20)
print(120//20)

